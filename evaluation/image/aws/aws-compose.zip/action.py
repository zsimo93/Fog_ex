def main(event, context):
    from PIL import Image, ImageFile
    import boto3
    import io
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    cl = boto3.client("s3")

    data = io.BytesIO()
    cl.download_fileobj("my-userdata", event["id1"], data)
    image0 = Image.open(data)

    data1 = io.BytesIO()
    cl.download_fileobj("my-userdata", event["id2"], data1)
    image1 = Image.open(data1)

    data2 = io.BytesIO()
    cl.download_fileobj("my-userdata", event["id3"], data2)
    image2 = Image.open(data2)

    data3 = io.BytesIO()
    cl.download_fileobj("my-userdata", event["id4"], data3)
    image3 = Image.open(data3)

    base_width, base_height = image0.size
    new_image = Image.new('RGB', (2 * base_width, 2 * base_height))

    new_image.paste(image0, (0, 0))
    new_image.paste(image1, (base_width, 0))
    new_image.paste(image2, (0, base_height))
    new_image.paste(image3, (base_width, base_height))

    newImage = io.BytesIO()
    new_image.save(newImage, 'PNG')
    newImage.seek(0)
    nameOut = "out.png"
    cl.upload_fileobj(newImage, "my-userdata", nameOut)
    return {"retId": nameOut}
