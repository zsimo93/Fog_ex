def main(event, context):
    from PIL import Image, ImageFile
    import boto3
    import io
    cl = boto3.client("s3")
    imIn = io.BytesIO()
    cl.download_fileobj("my-userdata", event["id"], imIn)
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    image = Image.open(imIn)

    image = image.convert('1')
    newImage = io.BytesIO()
    image.save(newImage, event["formatOut"])
    newImage.seek(0)
    nameOut = "bw-" + event["id"]
    cl.upload_fileobj(newImage, "my-userdata", nameOut)
    return {"retId": nameOut}
