from ffmpy import FFmpeg
import subprocess
import io
import boto3

subprocess.call(["cp", "/var/task/ffmpeg", "/tmp/"])
subprocess.call(["chmod", "755", "/tmp/ffmpeg"])

def main(event, context):
    cl = boto3.client("s3")
    vidIn = io.BytesIO()
    cl.download_fileobj("my-userdata", event["videoID"], vidIn)
    inconf = ""
    outconf = "-f mpegts -vf hue=s=0"
    vidIn.seek(0)

    ff = FFmpeg(inputs={"pipe:0": inconf},
                outputs={"pipe:1": outconf})

    o1, o2 = ff.run(input_data=vidIn.read(), stdout=subprocess.PIPE)

    sout = io.BytesIO(o1)
    nameOut = "grey-" + event["videoID"]
    cl.upload_fileobj(sout, "my-userdata", nameOut)

    return {"filename": nameOut}
